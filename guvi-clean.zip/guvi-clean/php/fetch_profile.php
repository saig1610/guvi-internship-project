<?php
header("Content-Type: application/json");

// Load MongoDB library
require '../vendor/autoload.php';

// Get email from POST or raw JSON input
$data = $_POST ?: json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';

if (!$email) {
    echo json_encode(["success" => false, "message" => "Email is required"]);
    exit;
}

try {
    // Use environment variable for Atlas connection
    $client = new MongoDB\Client(getenv("MONGO_URI"));
    $collection = $client->guvi->profiles;

    $user = $collection->findOne(['email' => $email]);

    if ($user) {
        $userArray = json_decode(json_encode($user), true);
        unset($userArray['_id']); // Remove internal Mongo ID
        echo json_encode(["success" => true, "user" => $userArray]);
    } else {
        echo json_encode(["success" => false, "message" => "User not found in MongoDB"]);
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "MongoDB error: " . $e->getMessage()]);
}
