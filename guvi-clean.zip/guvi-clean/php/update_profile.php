<?php
header("Content-Type: application/json");

require '../vendor/autoload.php';

// Get input from POST or raw JSON
$data = $_POST ?: json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$age = $data['age'] ?? '';
$dob = $data['dob'] ?? '';
$contact = $data['contact'] ?? '';

if (!$email) {
    echo json_encode(["success" => false, "message" => "Email is required"]);
    exit;
}

try {
    $client = new MongoDB\Client(getenv("MONGO_URI"));
    $collection = $client->guvi->profiles;

    $updateResult = $collection->updateOne(
        ['email' => $email],
        ['$set' => [
            'age' => $age,
            'dob' => $dob,
            'contact' => $contact
        ]],
        ['upsert' => true]
    );

    echo json_encode(["success" => true]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "MongoDB update failed: " . $e->getMessage()]);
}
