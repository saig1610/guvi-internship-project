<?php
echo "GUVI Project is running.";
?>
